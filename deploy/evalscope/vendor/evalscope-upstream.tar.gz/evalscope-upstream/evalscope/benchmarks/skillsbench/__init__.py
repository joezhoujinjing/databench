"""SkillsBench benchmark adapter."""

"""MCP-Atlas benchmark adapter."""
